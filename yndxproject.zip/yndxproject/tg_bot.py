import logging
from telegram.ext import Application, MessageHandler, filters, Updater
# from config import BOT_TOKEN
from telegram.ext import CommandHandler
import apimoex
# import streamlit as st
import pandas as pd
import numpy as np
import requests
import matplotlib.pyplot as plt
logging.basicConfig(
format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s', level = logging.DEBUG
)

logger = logging.getLogger(__name__)
TOKEN='6180763745:AAEb2HvaUs8eUndZ-9eywbsAGTNs864uN5g'
# updater = Updater(TOKEN)
async def start(update, context):
    """Отправляет сообщение когда получена команда /start"""
    user = update.effective_user
    await update.message.reply_html(
        f"Привет {user.mention_html()}! Я Инвест-бот."
        f"\nВведите 6 тикеров акций с moex, а я сделаю анализ портфеля с ними по заданному максимальному риску."
        f"\nВ формате: ticker ticker ticker ticker ticker ticker risk",
    )


async def invest(update, context):
    await update.message.reply_html(
        rf"Введите 6 тикеров акций",
    )


async def invest_tickers(update, context):
    zxcv = update.message.text.split()
    if len(zxcv) != 7:
        await update.message.reply_text('Некорректные данные.')
        return
    else:
        await update.message.reply_text('Данные получены')
    tickers = zxcv[:-1]
    max_risk = int(zxcv[6])


    class Ticker:
        def __init__(self, tick, delta, risk, data, deltad):
            self.tick = tick
            self.delta = delta
            self.risk = risk
            self.prices = data
            self.deltad = deltad

    ticks = {}

    def load_historical_data(ticker, ticks=ticks):
        session1 = requests.Session()
        historiscal_data = apimoex.get_board_history(session=session1, security=ticker, start='2022-03-15',
                                                     end='2023-04-28',
                                                     board='TQBR')
        data = pd.DataFrame(historiscal_data)
        data = data.iloc[:-1, :]
        data['TRADEDATE'] = pd.to_datetime(data['TRADEDATE'])
        data.set_index('TRADEDATE', inplace=True)
        data.dropna(subset=['CLOSE'])
        data = data[data.CLOSE > 0]
        data = data.reindex(index=data.index[::-1])
        data['deltad'] = data['CLOSE'].rolling(window=2, center=False).apply(lambda x: x[1] / x[0] - 1)
        data = data[data.deltad > 0]
        data = data.reindex(index=data.index[::-1])
        print(data)
        delta = data['deltad']
        delta = sum(delta) / len(delta)
        risk = sum([abs(delta - i) for i in data['deltad']]) / len(data['deltad'])

        ticks[ticker] = Ticker(ticker, delta, risk, list(data['CLOSE']), list(data['deltad']))
        print(list(data['deltad']))
        return data


    '''# data_load_state = st.text('Загружаем базовую информацию...')
    st.subheader('Список котировок для анализа')
    st.text(' '.join(tickers))
    st.subheader('Котировки цен инсрументов')
    for ticker in tickers.split():
        history = load_historical_data(ticker)
        st.subheader(ticker)
        st.line_chart(history['CLOSE'])'''
    for ticker in tickers:

        history = load_historical_data(ticker)
        plt.plot(history.index, history['CLOSE'])
        plt.title(ticker)
        plt.savefig(f'{ticker}.png')
        await context.bot.send_photo(chat_id=update.effective_message.chat_id, photo=open(f'{ticker}.png', 'rb'))
        plt.clf()
    D = []
    mdx = []
    for i in ticks.keys():
        mdx.append(len(ticks[i].deltad))
    mdx = min(mdx)
    for i in ticks.keys():
        D.append(ticks[i].deltad[:mdx - 1] * 100)
        print(len(ticks[i].deltad))
    print(D)
    D = np.array(D, np.float64)
    print(D)
    m, n = D.shape
    # history_load_state.text('Информация... Загружена!')
    d = np.zeros([m, 1])  # столбец для средней доходности
    for i in range(len(ticks.keys())):
        d[i, 0] = ticks[list(ticks.keys())[i]].delta * 100
        print(d[i, 0])
    abc = pd.DataFrame([tickers, [i[0] for i in d]])
    '''plt.title(' '.join(tickers))
    plt.table(cellText=abc.values, colLabels=abc.columns, loc='center')
    plt.savefig(f'pribl{" ".join(tickers)}.png')'''
    # await context.bot.send_photo(chat_id=update.effective_message.chat_id, photo=open(f'pribl{" ".join(tickers)}.png'))
    await update.message.reply_html(
        f"Ожидаемый доход:"
        f"\n\n{abc[0][0]} - {abc[0][1]}%"
        f"\n{abc[1][0]} - {abc[1][1]}%"
        f"\n{abc[2][0]} - {abc[2][1]}%"
        f"\n{abc[3][0]} - {abc[3][1]}%"
        f"\n{abc[4][0]} - {abc[4][1]}%"
        f"\n{abc[5][0]} - {abc[5][1]}%",
    )

    print("Средняя доходность акций 1-6 : \n %s" % d)
    CV = np.cov(D)
    abc = pd.DataFrame(CV)

    print("Ковариационная матрица  CV: \n %s" % CV)
    # max_risk = st.text_input('Какому максимальному риску вы готовы себя подвергнуть(%): ', value=10)
    b1, b2, b3, b4, b5, b6 = [None for _ in range(6)]
    max_win = 0
    my_risk = 0
    for a1 in range(0, 76, 5):
        for a2 in range(0, 101 - a1 - 4 * 5, 5):
            for a3 in range(0, 101 - a1 - a2 - 3 * 5, 5):
                for a4 in range(0, 101 - a1 - a2 - a3 - 2 * 5, 5):
                    for a5 in range(0, 101 - a1 - a2 - a3 - a4 - 5, 5):
                        for a6 in range(0, 101 - a1 - a2 - a3 - a4 - a5, 5):
                            if a1 + a2 + a3 + a4 + a5 + a6 != 100:
                                continue
                            win = (a1 * d[0] + a2 * d[1] + a3 * d[2] + a4 * d[3] + a5 * d[4] + a6 * d[5]) / 100
                            lose = round(
                                np.sqrt(np.dot(np.dot([a1, a2, a3, a4, a5, a6], CV), [a1, a2, a3, a4, a5, a6])), 2)
                            if lose <= float(max_risk) and win > max_win:
                                b1, b2, b3, b4, b5, b6 = a1, a2, a3, a4, a5, a6
                                max_win = win
                                my_risk = lose
                                print(win, lose)
                                print(b1, b2, b3, b4, b5, b6)
                                # print()
    fig1, ax1 = plt.subplots()
    ax1.pie([b1, b2, b3, b4, b5, b6], labels=tickers)
    pngfile = f'{tickers}.png'
    plt.savefig(pngfile)
    # st.write(pd.DataFrame({'тикер': tickers.split(), 'процент': [b1, b2, b3, b4, b5, b6]}))
    b_max = max([b1, b2, b3, b4, b5, b6])
    t_max = tickers[[b1, b2, b3, b4, b5, b6].index(b_max)]
    # st.image(pngfile, caption=None, width=None, use_column_width=None, clamp=False, channels="RGB",
    #         output_format="auto")
    # st.text(f'Наибольшую важность для инвестора имеют акции компании {t_max}')
    await context.bot.send_photo(chat_id=update.effective_message.chat_id, photo=open(pngfile, 'rb'))
    # await update.message.reply_html(f'Наибольшую важность для инвестора имеют акции компании {t_max}')
    await update.message.reply_html(
        f"Содержимое портфеля:"
        f"\n\n{tickers[0]} - {b1}%"
        f"\n{tickers[1]} - {b2}%"
        f"\n{tickers[2]} - {b3}%"
        f"\n{tickers[3]} - {b4}%"
        f"\n{tickers[4]} - {b5}%"
        f"\n{tickers[5]} - {b6}%"
        f"\nРиск={my_risk}%\nПрибыль={max_risk}%",
    )
    plt.clf()

def main():
    application = Application.builder().token('6180763745:AAEb2HvaUs8eUndZ-9eywbsAGTNs864uN5g').build()
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("invest", invest))
    text_handler = MessageHandler(filters.TEXT, invest_tickers)
    application.add_handler(text_handler)
    application.run_polling()


# Запускаем функцию main() в случае запуска скрипта.
if __name__ == '__main__':
    main()